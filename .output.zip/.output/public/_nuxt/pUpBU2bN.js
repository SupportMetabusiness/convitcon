import{P as a,c as n,m as o,o as s}from"./DwpmnTMM.js";const m={__name:"index",async setup(c){let e,t;return[e,t]=a(()=>o("/admin/products")),await e,t(),(r,_)=>(s(),n("div"))}};export{m as default};
