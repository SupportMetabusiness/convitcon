import{Q as a,c as n,p as o,o as s}from"./Csi6HIsI.js";const i={__name:"index",async setup(c){let e,t;return[e,t]=a(()=>o("/admin/products")),await e,t(),(r,_)=>(s(),n("div"))}};export{i as default};
