import { d as defineEventHandler, g as getMethod, h as getQuery, r as readBody } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const activeViewers = /* @__PURE__ */ new Map();
const lastUpdate = /* @__PURE__ */ new Map();
const generateRealisticViewers = (baseCount, timeOfDay) => {
  let multiplier = 1;
  if (timeOfDay >= 9 && timeOfDay <= 11 || timeOfDay >= 14 && timeOfDay <= 16 || timeOfDay >= 19 && timeOfDay <= 22) {
    multiplier = 1.5 + Math.random() * 0.5;
  } else if (timeOfDay >= 1 && timeOfDay <= 6) {
    multiplier = 0.3 + Math.random() * 0.3;
  } else {
    multiplier = 0.8 + Math.random() * 0.4;
  }
  const variation = Math.random() * 0.3 - 0.15;
  const finalCount = Math.floor(baseCount * multiplier * (1 + variation));
  return Math.max(finalCount, 10);
};
const updateViewersCount = (productId) => {
  const now = Date.now();
  const currentHour = (/* @__PURE__ */ new Date()).getHours();
  let currentViewers = activeViewers.get(productId);
  const lastUpdateTime = lastUpdate.get(productId) || 0;
  if (!currentViewers || now - lastUpdateTime > 3e5) {
    const dbData = db.prepare(
      `
            SELECT viewers_count FROM product_views WHERE product_id = ?
        `
    ).get(productId);
    const baseCount = dbData ? dbData.viewers_count : Math.floor(Math.random() * 400) + 200;
    currentViewers = generateRealisticViewers(baseCount, currentHour);
  } else {
    const timeDiff = now - lastUpdateTime;
    if (timeDiff > 1e4) {
      const change = Math.floor(Math.random() * 10) - 4;
      currentViewers = Math.max(currentViewers + change, 10);
    }
  }
  activeViewers.set(productId, currentViewers);
  lastUpdate.set(productId, now);
  if (Math.random() < 0.1) {
    try {
      db.prepare(
        `
                INSERT OR REPLACE INTO product_views (product_id, viewers_count, last_updated)
                VALUES (?, ?, datetime('now'))
            `
      ).run(productId, currentViewers);
    } catch (error) {
      console.error("Error updating viewers in DB:", error);
    }
  }
  return currentViewers;
};
const viewers = defineEventHandler(async (event) => {
  const method = getMethod(event);
  if (method === "GET") {
    try {
      const query = getQuery(event);
      const productId = query.id ? Number(query.id) : 1;
      const viewersCount = updateViewersCount(productId);
      return {
        success: true,
        data: {
          productId,
          viewersCount,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          isLive: true
        }
      };
    } catch (error) {
      console.error("\u274C Error getting viewers:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  if (method === "POST") {
    try {
      const body = await readBody(event);
      const { productId, action } = body;
      if (action === "join") {
        const currentViewers = updateViewersCount(productId);
        const newCount = currentViewers + Math.floor(Math.random() * 3) + 1;
        activeViewers.set(productId, newCount);
        lastUpdate.set(productId, Date.now());
        return {
          success: true,
          data: {
            viewersCount: newCount,
            message: "Viewer joined"
          }
        };
      }
      if (action === "leave") {
        const currentViewers = activeViewers.get(productId) || 0;
        const newCount = Math.max(currentViewers - Math.floor(Math.random() * 2) - 1, 10);
        activeViewers.set(productId, newCount);
        lastUpdate.set(productId, Date.now());
        return {
          success: true,
          data: {
            viewersCount: newCount,
            message: "Viewer left"
          }
        };
      }
      return {
        success: false,
        error: "Invalid action"
      };
    } catch (error) {
      console.error("\u274C Error updating viewers:", error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  return {
    success: false,
    error: "Method not allowed"
  };
});
setInterval(
  () => {
    for (const [productId] of activeViewers) {
      updateViewersCount(productId);
    }
  },
  Math.random() * 15e3 + 15e3
);

export { viewers as default };
//# sourceMappingURL=viewers.mjs.map
