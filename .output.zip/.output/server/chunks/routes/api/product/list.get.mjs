import { d as defineEventHandler, c as createError } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const list_get = defineEventHandler(async (event) => {
  try {
    const betterSqlite3 = await import('better-sqlite3');
    const db = new betterSqlite3.default("database.sqlite");
    const products = db.prepare(
      `
            SELECT
                p.*,
                GROUP_CONCAT(DISTINCT pi.image_url) as images
            FROM product p
            LEFT JOIN product_images pi ON p.id = pi.product_id
            GROUP BY p.id
            ORDER BY p.id DESC
        `
    ).all();
    const formattedProducts = products.map((product) => ({
      id: product.id,
      name: product.name,
      description: product.description,
      price: product.price,
      discount: product.discount,
      stock: product.stock,
      currency: product.currency || "USD",
      slug: product.slug,
      images: product.images ? product.images.split(",") : [],
      created_at: product.created_at,
      updated_at: product.updated_at
    }));
    db.close();
    return formattedProducts;
  } catch (error) {
    console.error("Error fetching products:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
