import { d as defineEventHandler, c as createError } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const list_get = defineEventHandler(async (event) => {
  try {
    const stmt = db.prepare("SELECT * FROM product ORDER BY id DESC");
    const products = stmt.all();
    return {
      success: true,
      data: products
    };
  } catch (error) {
    console.error("Error fetching products:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
