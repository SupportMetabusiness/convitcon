import { d as defineEventHandler, e as getRouterParam, c as createError } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const _id__get = defineEventHandler(async (event) => {
  try {
    const productId = getRouterParam(event, "id");
    if (!productId) {
      throw createError({
        statusCode: 400,
        statusMessage: "Product ID is required"
      });
    }
    const product = db.prepare(
      `
            SELECT * FROM product
            WHERE id = ?
        `
    ).get(productId);
    if (!product) {
      throw createError({
        statusCode: 404,
        statusMessage: "Product not found"
      });
    }
    return {
      success: true,
      data: product
    };
  } catch (error) {
    console.error("Error fetching product:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
