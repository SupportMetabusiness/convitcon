import { d as defineEventHandler } from '../../_/nitro.mjs';
import { a as axiosInstance } from '../../_/axios-config.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'axios';

const countryToLanguage = {
  AE: "ar",
  AL: "sq",
  AM: "hy",
  AR: "ar",
  AT: "de",
  AU: "en",
  AZ: "az",
  BD: "bn",
  BE: "nl",
  BG: "bg",
  BH: "ar",
  BR: "pt",
  CA: "en",
  CH: "de",
  CL: "es",
  CN: "zh",
  CO: "es",
  CZ: "cs",
  DE: "de",
  DK: "da",
  EE: "et",
  ES: "es",
  ET: "am",
  FI: "fi",
  FO: "fo",
  FR: "fr",
  GB: "en",
  GE: "ka",
  GL: "kl",
  GR: "el",
  HK: "zh",
  HR: "hr",
  HU: "hu",
  ID: "id",
  IL: "he",
  IN: "hi",
  IR: "fa",
  IS: "is",
  IT: "it",
  JP: "ja",
  KE: "sw",
  KG: "ky",
  KH: "km",
  KR: "ko",
  KW: "ar",
  KZ: "kk",
  LA: "lo",
  LK: "si",
  LT: "lt",
  LV: "lv",
  MM: "my",
  MN: "mn",
  MO: "zh",
  MT: "mt",
  MX: "es",
  MY: "ms",
  NG: "ha",
  NL: "nl",
  NO: "no",
  NP: "ne",
  OM: "ar",
  PE: "es",
  PH: "tl",
  PK: "ur",
  PL: "pl",
  PR: "es",
  PT: "pt",
  QA: "ar",
  RO: "ro",
  RS: "sr",
  RU: "ru",
  RW: "rw",
  SA: "ar",
  SE: "sv",
  SG: "zh-SG",
  SK: "sk",
  SO: "so",
  TH: "th",
  TJ: "tg",
  TR: "tr",
  TW: "zh",
  TZ: "sw",
  UA: "uk",
  US: "en",
  UY: "es",
  UZ: "uz",
  VE: "es",
  VN: "vi",
  ZA: "zu"
};
const getGeoData = async () => {
  try {
    const response = await axiosInstance.get("https://get.geojs.io/v1/ip/geo.json");
    return response.data;
  } catch (error) {
    console.error("Failed to fetch geo data:", error);
    return {
      country_code: "US",
      country: "United States",
      city: "Unknown",
      region: "Unknown",
      latitude: "0",
      longitude: "0",
      timezone: "UTC",
      ip: "unknown"
    };
  }
};
const getLanguageFromCountry = (countryCode) => {
  return countryToLanguage[countryCode.toUpperCase()] || "en";
};
const geolocation_get = defineEventHandler(async () => {
  try {
    const geoData = await getGeoData();
    const language = getLanguageFromCountry(geoData.country_code);
    return {
      success: true,
      data: {
        ip: geoData.ip,
        country: geoData.country_code,
        countryName: geoData.country,
        language
      }
    };
  } catch (error) {
    console.error("Geolocation API error:", error);
    return {
      success: false,
      error: "Failed to fetch geolocation data"
    };
  }
});

export { geolocation_get as default };
//# sourceMappingURL=geolocation.get.mjs.map
