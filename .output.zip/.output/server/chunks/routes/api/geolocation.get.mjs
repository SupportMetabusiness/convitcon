import { d as defineEventHandler, h as getHeader } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const geolocation_get = defineEventHandler(async (event) => {
  var _a;
  try {
    const clientIP = getClientIP(event) || getHeader(event, "x-forwarded-for") || getHeader(event, "x-real-ip") || ((_a = event.node.req.socket) == null ? void 0 : _a.remoteAddress) || "127.0.0.1";
    console.log("\u{1F30D} DEBUG: Client IP detected:", clientIP);
    if (clientIP === "127.0.0.1" || clientIP === "::1" || clientIP.startsWith("192.168.") || clientIP.startsWith("10.")) {
      console.log("\u{1F3E0} DEBUG: Local IP detected, returning default country");
      return {
        success: true,
        data: {
          ip: clientIP,
          country: "VN",
          // Default to Vietnam for development
          countryName: "Viet Nam",
          language: "vi"
        }
      };
    }
    try {
      const geoResponse = await $fetch(`http://ip-api.com/json/${clientIP}?fields=status,country,countryCode,query`);
      console.log("\u{1F30D} DEBUG: Geolocation API response:", geoResponse);
      if (geoResponse.status === "success") {
        const countryCode = geoResponse.countryCode;
        let language = "en";
        switch (countryCode) {
          case "FR":
            language = "fr";
            break;
          case "VN":
            language = "vi";
            break;
          case "US":
          case "GB":
          case "AU":
          case "CA":
            language = "en";
            break;
          default:
            language = "en";
        }
        return {
          success: true,
          data: {
            ip: clientIP,
            country: countryCode,
            countryName: geoResponse.country,
            language
          }
        };
      }
    } catch (geoError) {
      console.error("\u{1F6A8} DEBUG: Geolocation API error:", geoError);
    }
    try {
      const fallbackResponse = await $fetch(`https://ipapi.co/${clientIP}/json/`);
      console.log("\u{1F30D} DEBUG: Fallback API response:", fallbackResponse);
      if (fallbackResponse.country_code) {
        const countryCode = fallbackResponse.country_code;
        let language = "en";
        switch (countryCode) {
          case "FR":
            language = "fr";
            break;
          case "VN":
            language = "vi";
            break;
          default:
            language = "en";
        }
        return {
          success: true,
          data: {
            ip: clientIP,
            country: countryCode,
            countryName: fallbackResponse.country_name,
            language
          }
        };
      }
    } catch (fallbackError) {
      console.error("\u{1F6A8} DEBUG: Fallback API error:", fallbackError);
    }
    console.log("\u26A0\uFE0F DEBUG: All geolocation APIs failed, using default");
    return {
      success: true,
      data: {
        ip: clientIP,
        country: "US",
        countryName: "United States",
        language: "en"
      }
    };
  } catch (error) {
    console.error("\u{1F6A8} DEBUG: Geolocation endpoint error:", error);
    return {
      success: false,
      error: "Failed to detect location",
      data: {
        ip: "127.0.0.1",
        country: "US",
        countryName: "United States",
        language: "en"
      }
    };
  }
});

export { geolocation_get as default };
//# sourceMappingURL=geolocation.get.mjs.map
