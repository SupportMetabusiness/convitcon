import { d as defineEventHandler } from '../../_/nitro.mjs';
import { g as getFullDeviceInfo } from '../../_/device-info.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const deviceInfo = defineEventHandler(async (event) => {
  try {
    const deviceInfo = await getFullDeviceInfo(event);
    console.log("\u2705 DEBUG: Device info collected:", deviceInfo);
    return {
      success: true,
      data: deviceInfo
    };
  } catch (error) {
    console.error("\u{1F6A8} DEBUG: Device info error:", error);
    return {
      success: false,
      error: "Failed to get device info",
      data: {
        ip: "127.0.0.1",
        location: {
          country: "VN",
          countryName: "Viet Nam",
          city: "Unknown",
          region: "Unknown",
          timezone: "Asia/Ho_Chi_Minh",
          isp: "Unknown"
        },
        device: {
          browser: "Unknown",
          browserVersion: "Unknown",
          os: "Unknown",
          osVersion: "Unknown",
          deviceType: "Desktop",
          isMobile: false,
          userAgent: ""
        },
        headers: {
          userAgent: "",
          acceptLanguage: "",
          referer: ""
        },
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
  }
});

export { deviceInfo as default };
//# sourceMappingURL=device-info.mjs.map
