import { d as defineEventHandler, c as createError, e as getRouterParam } from '../../../../_/nitro.mjs';
import db from '../../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const status = defineEventHandler(async (event) => {
  if (event.node.req.method !== "GET") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method Not Allowed"
    });
  }
  try {
    const id = getRouterParam(event, "id");
    if (!id || isNaN(Number(id))) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid payment ID"
      });
    }
    const stmt = db.prepare(
      "SELECT id, status, created_at FROM payment_info WHERE id = ?"
    );
    const payment = stmt.get(Number(id));
    if (!payment) {
      throw createError({
        statusCode: 404,
        statusMessage: "Payment not found"
      });
    }
    return {
      success: true,
      payment: {
        id: payment.id,
        status: payment.status,
        createdAt: payment.created_at
      }
    };
  } catch {
  }
});

export { status as default };
//# sourceMappingURL=status.mjs.map
