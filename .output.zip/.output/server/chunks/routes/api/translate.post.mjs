import { d as defineEventHandler, r as readBody } from '../../_/nitro.mjs';
import { a as axiosInstance } from '../../_/axios-config.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'axios';

const translateText = async (text, targetLang) => {
  try {
    const response = await axiosInstance.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`);
    const data = response.data;
    return data[0][0][0];
  } catch (error) {
    console.error("Translation error:", error);
    return text;
  }
};
const translateMultipleTexts = async (texts, targetLang) => {
  const translatedTexts = {};
  try {
    for (const [key, text] of Object.entries(texts)) {
      translatedTexts[key] = await translateText(text, targetLang);
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  } catch (error) {
    console.error("Multiple translation error:", error);
  }
  return translatedTexts;
};
const translate_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    if (!body.texts || !body.targetLang) {
      return {
        success: false,
        error: "Missing required fields: texts and targetLang"
      };
    }
    const validLanguages = ["vi", "en", "fr", "de", "es", "it", "pt", "ru", "ja", "ko", "zh", "ar", "hi", "th"];
    if (!validLanguages.includes(body.targetLang)) {
      return {
        success: false,
        error: "Invalid target language"
      };
    }
    const translatedTexts = await translateMultipleTexts(body.texts, body.targetLang);
    return {
      success: true,
      translatedTexts
    };
  } catch (error) {
    console.error("Translation API error:", error);
    return {
      success: false,
      error: "Internal server error"
    };
  }
});

export { translate_post as default };
//# sourceMappingURL=translate.post.mjs.map
