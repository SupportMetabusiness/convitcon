import { d as defineEventHandler, g as getMethod, r as readBody } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const settings = defineEventHandler(async (event) => {
  const method = getMethod(event);
  if (method === "GET") {
    try {
      const stmt = db.prepare("SELECT currency FROM product ORDER BY id DESC LIMIT 1");
      const result = stmt.get();
      const defaultCurrency = (result == null ? void 0 : result.currency) || "USD";
      return {
        success: true,
        data: {
          defaultCurrency
        }
      };
    } catch (error) {
      console.error("Error fetching settings:", error);
      return {
        success: false,
        error: "Failed to fetch settings"
      };
    }
  }
  if (method === "POST") {
    try {
      const body = await readBody(event);
      const { defaultCurrency } = body;
      const updateStmt = db.prepare('UPDATE product SET currency = ? WHERE currency IS NULL OR currency = ""');
      updateStmt.run(defaultCurrency);
      return {
        success: true,
        message: "Settings updated successfully"
      };
    } catch (error) {
      console.error("Error updating settings:", error);
      return {
        success: false,
        error: "Failed to update settings"
      };
    }
  }
  return {
    success: false,
    error: "Method not allowed"
  };
});

export { settings as default };
//# sourceMappingURL=settings.mjs.map
