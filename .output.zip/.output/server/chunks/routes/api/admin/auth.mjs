import { d as defineEventHandler, g as getMethod, r as readBody, s as setCookie, a as getCookie, b as deleteCookie } from '../../../_/nitro.mjs';
import bcrypt from 'bcryptjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const auth = defineEventHandler(async (event) => {
  const method = getMethod(event);
  if (method === "POST") {
    try {
      const body = await readBody(event);
      const { action, username, password, currentPassword, newPassword } = body;
      if (action === "login") {
        if (!username || !password) {
          return {
            success: false,
            error: "Vui l\xF2ng nh\u1EADp t\xEAn \u0111\u0103ng nh\u1EADp v\xE0 m\u1EADt kh\u1EA9u"
          };
        }
        const stmt = db.prepare("SELECT * FROM admin_account WHERE username = ?");
        const admin = stmt.get(username);
        if (!admin) {
          return {
            success: false,
            error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng"
          };
        }
        const isValidPassword = await bcrypt.compare(password, admin.password);
        if (!isValidPassword) {
          return {
            success: false,
            error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng"
          };
        }
        const token = Buffer.from(`${username}:${Date.now()}`).toString("base64");
        setCookie(event, "admin-token", token, {
          httpOnly: true,
          secure: false,
          sameSite: "strict",
          maxAge: 60 * 60 * 24 * 7
          // 7 days
        });
        return {
          success: true,
          message: "\u0110\u0103ng nh\u1EADp th\xE0nh c\xF4ng",
          token
        };
      }
      if (action === "change-password") {
        if (!currentPassword || !newPassword) {
          return {
            success: false,
            error: "Vui l\xF2ng nh\u1EADp m\u1EADt kh\u1EA9u hi\u1EC7n t\u1EA1i v\xE0 m\u1EADt kh\u1EA9u m\u1EDBi"
          };
        }
        const token = getCookie(event, "admin-token");
        if (!token) {
          return {
            success: false,
            error: "B\u1EA1n c\u1EA7n \u0111\u0103ng nh\u1EADp \u0111\u1EC3 th\u1EF1c hi\u1EC7n thao t\xE1c n\xE0y"
          };
        }
        const adminUsername = Buffer.from(token, "base64").toString().split(":")[0];
        const stmt = db.prepare("SELECT * FROM admin_account WHERE username = ?");
        const admin = stmt.get(adminUsername);
        if (!admin) {
          return {
            success: false,
            error: "Kh\xF4ng t\xECm th\u1EA5y t\xE0i kho\u1EA3n admin"
          };
        }
        const isValidCurrentPassword = await bcrypt.compare(currentPassword, admin.password);
        if (!isValidCurrentPassword) {
          return {
            success: false,
            error: "M\u1EADt kh\u1EA9u hi\u1EC7n t\u1EA1i kh\xF4ng \u0111\xFAng"
          };
        }
        const saltRounds = 12;
        const hashedNewPassword = await bcrypt.hash(newPassword, saltRounds);
        const updateStmt = db.prepare("UPDATE admin_account SET password = ? WHERE username = ?");
        updateStmt.run(hashedNewPassword, adminUsername);
        return {
          success: true,
          message: "\u0110\u1ED5i m\u1EADt kh\u1EA9u th\xE0nh c\xF4ng"
        };
      }
      if (action === "create-default") {
        const checkStmt = db.prepare("SELECT COUNT(*) as count FROM admin_account");
        const result = checkStmt.get();
        if (result.count > 0) {
          return {
            success: false,
            error: "T\xE0i kho\u1EA3n admin \u0111\xE3 t\u1ED3n t\u1EA1i"
          };
        }
        const defaultUsername = "admin";
        const defaultPassword = "admin123";
        const saltRounds = 12;
        const hashedPassword = await bcrypt.hash(defaultPassword, saltRounds);
        const insertStmt = db.prepare("INSERT INTO admin_account (username, password) VALUES (?, ?)");
        insertStmt.run(defaultUsername, hashedPassword);
        return {
          success: true,
          message: "T\xE0i kho\u1EA3n admin m\u1EB7c \u0111\u1ECBnh \u0111\xE3 \u0111\u01B0\u1EE3c t\u1EA1o",
          credentials: {
            username: defaultUsername,
            password: defaultPassword
          }
        };
      }
      return {
        success: false,
        error: "H\xE0nh \u0111\u1ED9ng kh\xF4ng h\u1EE3p l\u1EC7"
      };
    } catch (error) {
      console.error("Error in admin auth:", error);
      return {
        success: false,
        error: "C\xF3 l\u1ED7i x\u1EA3y ra trong qu\xE1 tr\xECnh x\u1EED l\xFD"
      };
    }
  }
  if (method === "GET") {
    try {
      const token = getCookie(event, "admin-token");
      if (!token) {
        return {
          success: false,
          authenticated: false
        };
      }
      const adminUsername = Buffer.from(token, "base64").toString().split(":")[0];
      const stmt = db.prepare("SELECT username FROM admin_account WHERE username = ?");
      const admin = stmt.get(adminUsername);
      if (!admin) {
        return {
          success: false,
          authenticated: false
        };
      }
      return {
        success: true,
        authenticated: true,
        username: admin.username
      };
    } catch (error) {
      return {
        success: false,
        authenticated: false
      };
    }
  }
  if (method === "DELETE") {
    deleteCookie(event, "admin-token");
    return {
      success: true,
      message: "\u0110\u0103ng xu\u1EA5t th\xE0nh c\xF4ng"
    };
  }
  return {
    success: false,
    error: "Ph\u01B0\u01A1ng th\u1EE9c kh\xF4ng \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3"
  };
});

export { auth as default };
//# sourceMappingURL=auth.mjs.map
