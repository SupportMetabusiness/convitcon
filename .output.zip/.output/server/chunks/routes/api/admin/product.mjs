import { d as defineEventHandler, r as readBody, c as createError } from '../../../_/nitro.mjs';
import db from '../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const product = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z;
  const method = event.method;
  try {
    if (method === "GET") {
      const stmt = db.prepare("SELECT * FROM product ORDER BY id DESC");
      const products = stmt.all();
      return {
        success: true,
        data: products
      };
    }
    if (method === "POST") {
      const body = await readBody(event);
      const insertStmt = db.prepare(`
        INSERT INTO product (name, description, price, discount, care_instructions, images, stock, slug, sizes, product_type, variants, currency, reviews)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const result = insertStmt.run((_a = body.name) != null ? _a : "", (_b = body.description) != null ? _b : "", (_c = parseFloat(body.price)) != null ? _c : 0, (_d = parseInt(body.discount)) != null ? _d : 0, (_e = body.care_instructions) != null ? _e : "", (_f = body.images) != null ? _f : "[]", (_g = parseInt(body.stock)) != null ? _g : 0, (_h = body.slug) != null ? _h : "", (_i = body.sizes) != null ? _i : "[]", (_j = body.product_type) != null ? _j : "clothing", (_k = body.variants) != null ? _k : "[]", (_l = body.currency) != null ? _l : "USD", (_m = body.reviews) != null ? _m : "[]");
      return {
        success: true,
        message: "Th\xEAm s\u1EA3n ph\u1EA9m th\xE0nh c\xF4ng",
        data: { id: result.lastInsertRowid }
      };
    }
    if (method === "PUT") {
      const body = await readBody(event);
      if (!body.id) {
        throw createError({
          statusCode: 400,
          statusMessage: "ID s\u1EA3n ph\u1EA9m l\xE0 b\u1EAFt bu\u1ED9c"
        });
      }
      const updateStmt = db.prepare(`
        UPDATE product
        SET name = ?, description = ?, price = ?, discount = ?,
            care_instructions = ?, images = ?, stock = ?, slug = ?, sizes = ?, product_type = ?, variants = ?, currency = ?, reviews = ?
        WHERE id = ?
      `);
      const result = updateStmt.run((_n = body.name) != null ? _n : "", (_o = body.description) != null ? _o : "", (_p = parseFloat(body.price)) != null ? _p : 0, (_q = parseInt(body.discount)) != null ? _q : 0, (_r = body.care_instructions) != null ? _r : "", (_s = body.images) != null ? _s : "[]", (_t = parseInt(body.stock)) != null ? _t : 0, (_u = body.slug) != null ? _u : "", (_v = body.sizes) != null ? _v : "[]", (_w = body.product_type) != null ? _w : "clothing", (_x = body.variants) != null ? _x : "[]", (_y = body.currency) != null ? _y : "USD", (_z = body.reviews) != null ? _z : "[]", body.id);
      if (result.changes === 0) {
        throw createError({
          statusCode: 404,
          statusMessage: "Kh\xF4ng t\xECm th\u1EA5y s\u1EA3n ph\u1EA9m"
        });
      }
      return {
        success: true,
        message: "C\u1EADp nh\u1EADt s\u1EA3n ph\u1EA9m th\xE0nh c\xF4ng"
      };
    }
    if (method === "DELETE") {
      const body = await readBody(event);
      if (!body.id) {
        throw createError({
          statusCode: 400,
          statusMessage: "ID s\u1EA3n ph\u1EA9m l\xE0 b\u1EAFt bu\u1ED9c"
        });
      }
      const deleteStmt = db.prepare("DELETE FROM product WHERE id = ?");
      const result = deleteStmt.run(body.id);
      if (result.changes === 0) {
        throw createError({
          statusCode: 404,
          statusMessage: "Kh\xF4ng t\xECm th\u1EA5y s\u1EA3n ph\u1EA9m"
        });
      }
      return {
        success: true,
        message: "X\xF3a s\u1EA3n ph\u1EA9m th\xE0nh c\xF4ng"
      };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "Ph\u01B0\u01A1ng th\u1EE9c kh\xF4ng \u0111\u01B0\u1EE3c ph\xE9p"
    });
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: error.message || "L\u1ED7i server"
    });
  }
});

export { product as default };
//# sourceMappingURL=product.mjs.map
