import { d as defineEventHandler, r as readBody, c as createError } from '../../../../_/nitro.mjs';
import db from '../../../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const config = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const method = event.method;
  try {
    if (method === "GET") {
      const stmt = db.prepare("SELECT * FROM telegram_settings LIMIT 1");
      const settings = stmt.get();
      return {
        success: true,
        data: settings != null ? settings : {
          id: 0,
          bot_token: "",
          chat_id: ""
        }
      };
    }
    if (method === "PUT") {
      const body = await readBody(event);
      const checkStmt = db.prepare("SELECT id FROM telegram_settings LIMIT 1");
      const existingSettings = checkStmt.get();
      if (existingSettings) {
        const updateStmt = db.prepare(`
                    UPDATE telegram_settings
                    SET bot_token = ?, chat_id = ?
                    WHERE id = ?
                `);
        updateStmt.run((_a = body.bot_token) != null ? _a : "", (_b = body.chat_id) != null ? _b : "", existingSettings.id);
      } else {
        const insertStmt = db.prepare(`
                    INSERT INTO telegram_settings (bot_token, chat_id)
                    VALUES (?, ?)
                `);
        insertStmt.run((_c = body.bot_token) != null ? _c : "", (_d = body.chat_id) != null ? _d : "");
      }
      return {
        success: true,
        message: "L\u01B0u c\u1EA5u h\xECnh Telegram th\xE0nh c\xF4ng"
      };
    }
    throw createError({
      statusCode: 405,
      statusMessage: "???"
    });
  } catch {
  }
});

export { config as default };
//# sourceMappingURL=config.mjs.map
