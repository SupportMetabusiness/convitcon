import { d as defineEventHandler, g as getMethod, c as createError, r as readBody } from '../../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const setup_post = defineEventHandler(async (event) => {
  if (getMethod(event) !== "POST") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method Not Allowed"
    });
  }
  try {
    const body = await readBody(event);
    const { bot_token, chat_id } = body;
    if (!bot_token || !chat_id) {
      throw createError({
        statusCode: 400,
        statusMessage: "Bot token and chat ID are required"
      });
    }
    const db = await import('../../../../_/db.mjs').then((m) => m.default);
    const stmt = db.prepare(`
            INSERT OR REPLACE INTO telegram_settings (id, bot_token, chat_id)
            VALUES (1, ?, ?)
        `);
    stmt.run(bot_token, chat_id);
    return {
      success: true,
      message: "Telegram configuration updated successfully"
    };
  } catch (error) {
    console.error("Error setting up Telegram:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

export { setup_post as default };
//# sourceMappingURL=setup.post.mjs.map
