import { d as defineEventHandler, c as createError } from '../../../../_/nitro.mjs';
import { g as getTelegramConfig } from '../../../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/db.mjs';
import 'better-sqlite3';
import 'path';

const testDetailed = defineEventHandler(async (event) => {
  if (event.node.req.method !== "POST") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method Not Allowed"
    });
  }
  try {
    console.log("\u{1F9EA} DEBUG: Starting detailed Telegram test...");
    const config = await getTelegramConfig();
    console.log("\u{1F4CB} DEBUG: Telegram config:", config);
    if (!config || !config.bot_token || !config.chat_id) {
      throw createError({
        statusCode: 400,
        statusMessage: "Telegram configuration not found or incomplete"
      });
    }
    console.log("\u{1F50D} DEBUG: Testing bot token...");
    const botInfoResponse = await fetch(`https://api.telegram.org/bot${config.bot_token}/getMe`);
    if (!botInfoResponse.ok) {
      const botError = await botInfoResponse.json();
      console.error("\u274C DEBUG: Bot token test failed:", botError);
      throw createError({
        statusCode: 400,
        statusMessage: `Invalid bot token: ${botError.description || "Unknown error"}`
      });
    }
    const botInfo = await botInfoResponse.json();
    console.log("\u2705 DEBUG: Bot info:", botInfo);
    console.log("\u{1F4F1} DEBUG: Testing chat_id...");
    const testMessage = `
\u{1F9EA} <b>TELEGRAM BOT TEST</b>

\u2705 <b>Bot Name:</b> <code>${botInfo.result.first_name}</code>
\u{1F194} <b>Bot Username:</b> <code>@${botInfo.result.username}</code>
\u{1F4AC} <b>Chat ID:</b> <code>${config.chat_id}</code>
\u{1F550} <b>Test Time:</b> <code>${(/* @__PURE__ */ new Date()).toLocaleString("vi-VN")}</code>

\u{1F389} <b>Test successful!</b> Your Telegram bot is working correctly.
        `.trim();
    const telegramUrl = `https://api.telegram.org/bot${config.bot_token}/sendMessage`;
    const response = await fetch(telegramUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        chat_id: config.chat_id,
        text: testMessage,
        parse_mode: "HTML",
        disable_web_page_preview: true
      })
    });
    if (!response.ok) {
      const errorData = await response.json();
      console.error("\u274C DEBUG: Send message failed:", errorData);
      let errorMessage = "Failed to send test message";
      if (errorData.error_code === 400) {
        errorMessage = "Bad Request - Check chat_id format";
      } else if (errorData.error_code === 401) {
        errorMessage = "Unauthorized - Check bot_token";
      } else if (errorData.error_code === 403) {
        errorMessage = "Forbidden - Bot may be blocked by user or not added to chat";
      } else if (errorData.error_code === 404) {
        errorMessage = "Not Found - Check chat_id";
      }
      throw createError({
        statusCode: 400,
        statusMessage: errorMessage
      });
    }
    const result = await response.json();
    console.log("\u2705 DEBUG: Test message sent successfully:", result);
    return {
      success: true,
      message: "Test Telegram notification sent successfully!",
      botInfo: {
        name: botInfo.result.first_name,
        username: botInfo.result.username,
        chatId: config.chat_id
      }
    };
  } catch (error) {
    console.error("\u{1F6A8} DEBUG: Error in detailed test Telegram API:", error);
    if (error.statusCode === 400) {
      throw createError({
        statusCode: 400,
        statusMessage: error.statusMessage || "Telegram configuration error"
      });
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Failed to test Telegram notification. Please check your configuration."
    });
  }
});

export { testDetailed as default };
//# sourceMappingURL=test-detailed.mjs.map
