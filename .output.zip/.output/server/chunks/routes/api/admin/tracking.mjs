import { d as defineEventHandler, g as getMethod, r as readBody, a as getCookie } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const tracking = defineEventHandler(async (event) => {
  const method = getMethod(event);
  if (method === "GET") {
    try {
      const defaultConfig = {
        facebook: {
          pixelId: process.env.FACEBOOK_PIXEL_ID || "",
          enabled: !!process.env.FACEBOOK_PIXEL_ID
        },
        google: {
          gtag: process.env.GOOGLE_GTAG_ID || "",
          enabled: !!process.env.GOOGLE_GTAG_ID
        },
        tiktok: {
          pixelId: process.env.TIKTOK_PIXEL_ID || "",
          enabled: !!process.env.TIKTOK_PIXEL_ID
        },
        snapchat: {
          pixelId: process.env.SNAPCHAT_PIXEL_ID || "",
          enabled: !!process.env.SNAPCHAT_PIXEL_ID
        },
        twitter: {
          pixelId: process.env.TWITTER_PIXEL_ID || "",
          enabled: !!process.env.TWITTER_PIXEL_ID
        }
      };
      return {
        success: true,
        data: defaultConfig
      };
    } catch (error) {
      console.error("Error fetching tracking config:", error);
      return {
        success: false,
        error: "Failed to fetch tracking configuration"
      };
    }
  }
  if (method === "POST") {
    try {
      const body = await readBody(event);
      const { config } = body;
      if (!config || typeof config !== "object") {
        return {
          success: false,
          error: "Invalid configuration data"
        };
      }
      const token = getCookie(event, "admin-token");
      if (!token) {
        return {
          success: false,
          error: "Unauthorized: Admin login required"
        };
      }
      console.log("Tracking config updated:", config);
      return {
        success: true,
        message: "Tracking configuration updated successfully"
      };
    } catch (error) {
      console.error("Error updating tracking config:", error);
      return {
        success: false,
        error: "Failed to update tracking configuration"
      };
    }
  }
  return {
    success: false,
    error: "Method not allowed"
  };
});

export { tracking as default };
//# sourceMappingURL=tracking.mjs.map
