import { d as defineEventHandler, e as getRouterParam, c as createError, r as readBody } from '../../../../../_/nitro.mjs';
import db from '../../../../../_/db.mjs';
import { s as sendStatusUpdateNotification } from '../../../../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const status = defineEventHandler(async (event) => {
  const method = event.method;
  const paymentId = getRouterParam(event, "id");
  console.log(`\u{1F50D} DEBUG: Status update request - Method: ${method}, Payment ID: ${paymentId}`);
  if (!paymentId) {
    console.error("\u274C DEBUG: Payment ID is missing");
    throw createError({
      statusCode: 400,
      statusMessage: "Payment ID is required"
    });
  }
  const numericPaymentId = parseInt(paymentId);
  if (isNaN(numericPaymentId)) {
    console.error("\u274C DEBUG: Invalid payment ID format:", paymentId);
    throw createError({
      statusCode: 400,
      statusMessage: "Payment ID must be a valid number"
    });
  }
  if (method === "PUT") {
    try {
      console.log(`\u{1F4DD} DEBUG: Reading request body for payment ${paymentId}`);
      const body = await readBody(event);
      console.log(`\u{1F4CB} DEBUG: Request body:`, body);
      const { status } = body;
      if (!status) {
        console.error("\u274C DEBUG: Status is missing in request body");
        throw createError({
          statusCode: 400,
          statusMessage: "Status is required"
        });
      }
      const statusMapping = {
        pending: "pending",
        sms: "sms",
        sms_error: "sms_error",
        wrong: "wrong",
        success: "success"
      };
      const mappedStatus = statusMapping[status] || status;
      const validStatuses = Object.values(statusMapping);
      if (!validStatuses.includes(mappedStatus)) {
        console.error("\u274C DEBUG: Invalid status:", status, "Valid statuses:", validStatuses);
        throw createError({
          statusCode: 400,
          statusMessage: `Invalid status. Must be one of: ${validStatuses.join(", ")}`
        });
      }
      console.log(`\u{1F50D} DEBUG: Checking if payment ${paymentId} exists`);
      let existingPayment;
      try {
        const checkStmt = db.prepare("SELECT id, status FROM payment_info WHERE id = ?");
        existingPayment = checkStmt.get(numericPaymentId);
      } catch (dbError) {
        console.error(`\u274C DEBUG: Database error checking payment ${paymentId}:`, dbError);
        throw createError({
          statusCode: 500,
          statusMessage: "Database error while checking payment"
        });
      }
      if (!existingPayment) {
        console.error(`\u274C DEBUG: Payment ${paymentId} not found in database`);
        throw createError({
          statusCode: 404,
          statusMessage: "Payment not found"
        });
      }
      console.log(`\u2705 DEBUG: Payment ${paymentId} exists, current status: ${existingPayment.status}, new status: ${mappedStatus}`);
      let updateResult;
      try {
        const tableInfo = db.prepare("PRAGMA table_info(payment_info)").all();
        const hasUpdatedAt = tableInfo.some((column) => column.name === "updated_at");
        if (hasUpdatedAt) {
          const updateStmt = db.prepare("UPDATE payment_info SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
          updateResult = updateStmt.run(mappedStatus, numericPaymentId);
        } else {
          console.log("\u26A0\uFE0F DEBUG: updated_at column not found, updating status only");
          const updateStmt = db.prepare("UPDATE payment_info SET status = ? WHERE id = ?");
          updateResult = updateStmt.run(mappedStatus, numericPaymentId);
        }
        console.log(`\u{1F504} DEBUG: Update completed for payment ${paymentId}, rows affected: ${updateResult.changes}`);
      } catch (dbError) {
        console.error(`\u274C DEBUG: Database error updating payment ${paymentId}:`, dbError);
        if (dbError.message && dbError.message.includes("updated_at")) {
          console.log("\u{1F504} DEBUG: Retrying update without updated_at column");
          try {
            const updateStmt = db.prepare("UPDATE payment_info SET status = ? WHERE id = ?");
            updateResult = updateStmt.run(mappedStatus, numericPaymentId);
            console.log(`\u2705 DEBUG: Update successful without updated_at, rows affected: ${updateResult.changes}`);
          } catch (retryError) {
            console.error(`\u274C DEBUG: Retry update failed:`, retryError);
            throw createError({
              statusCode: 500,
              statusMessage: `Database error: ${retryError.message || "Unknown database error"}`
            });
          }
        } else {
          throw createError({
            statusCode: 500,
            statusMessage: `Database error: ${dbError.message || "Unknown database error"}`
          });
        }
      }
      if (updateResult.changes === 0) {
        console.error(`\u274C DEBUG: No rows updated for payment ${paymentId}`);
        throw createError({
          statusCode: 404,
          statusMessage: "Payment not found or no changes made"
        });
      }
      console.log(`\u2705 DEBUG: Successfully updated payment ${paymentId}`);
      let updatedPayment;
      try {
        const updatedPaymentStmt = db.prepare("SELECT * FROM payment_info WHERE id = ?");
        updatedPayment = updatedPaymentStmt.get(numericPaymentId);
      } catch (dbError) {
        console.error(`\u274C DEBUG: Database error getting updated payment data for ${paymentId}:`, dbError);
        throw createError({
          statusCode: 500,
          statusMessage: "Database error while retrieving updated payment data"
        });
      }
      if (!updatedPayment) {
        console.error(`\u274C DEBUG: Failed to get updated payment data for ${paymentId}`);
        throw createError({
          statusCode: 500,
          statusMessage: "Failed to retrieve updated payment data"
        });
      }
      console.log(`\u2705 DEBUG: Successfully retrieved updated payment data:`, {
        id: updatedPayment.id,
        status: updatedPayment.status,
        updated_at: updatedPayment.updated_at
      });
      if (existingPayment.status !== mappedStatus) {
        console.log(`\u{1F4F1} DEBUG: Status changed for payment ${paymentId}: ${existingPayment.status} -> ${mappedStatus}`);
        sendStatusUpdateNotification(updatedPayment).then((success) => {
          if (success) {
            console.log(`\u2705 DEBUG: Telegram notification sent successfully for payment ${paymentId}`);
          } else {
            console.log(`\u26A0\uFE0F DEBUG: Failed to send Telegram notification for payment ${paymentId}`);
          }
        }).catch((error) => {
          console.error(`\u{1F6A8} DEBUG: Error sending Telegram notification for payment ${paymentId}:`, error);
        });
      } else {
        console.log(`\u2139\uFE0F DEBUG: Status unchanged for payment ${paymentId}, skipping Telegram notification`);
      }
      console.log(`\u2705 DEBUG: Status update completed successfully for payment ${paymentId}`);
      return {
        success: true,
        message: "Payment status updated successfully",
        data: updatedPayment
      };
    } catch (error) {
      console.error(`\u{1F6A8} DEBUG: Error updating payment status for ${paymentId}:`, error);
      if (error.statusCode) {
        throw error;
      }
      console.error(`\u{1F6A8} DEBUG: Full error details:`, {
        message: error.message,
        stack: error.stack,
        name: error.name
      });
      throw createError({
        statusCode: 500,
        statusMessage: "Internal Server Error - Failed to update payment status"
      });
    }
  }
  console.error(`\u274C DEBUG: Method ${method} not allowed`);
  throw createError({
    statusCode: 405,
    statusMessage: "Method not allowed"
  });
});

export { status as default };
//# sourceMappingURL=status.mjs.map
