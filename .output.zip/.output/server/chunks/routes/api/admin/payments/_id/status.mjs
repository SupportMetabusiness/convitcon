import { d as defineEventHandler, e as getRouterParam, c as createError, r as readBody } from '../../../../../_/nitro.mjs';
import db from '../../../../../_/db.mjs';
import { s as sendStatusUpdateNotification } from '../../../../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';

const status = defineEventHandler(async (event) => {
  const method = event.method;
  const paymentId = getRouterParam(event, "id");
  if (!paymentId) {
    throw createError({
      statusCode: 400,
      statusMessage: "Payment ID is required"
    });
  }
  if (method === "PUT") {
    try {
      const body = await readBody(event);
      const { status } = body;
      if (!status) {
        throw createError({
          statusCode: 400,
          statusMessage: "Status is required"
        });
      }
      const validStatuses = ["pending", "sms", "sms_error", "wrong", "success"];
      if (!validStatuses.includes(status)) {
        throw createError({
          statusCode: 400,
          statusMessage: "Invalid status. Must be one of: " + validStatuses.join(", ")
        });
      }
      const checkStmt = db.prepare("SELECT id FROM payment_info WHERE id = ?");
      const existingPayment = checkStmt.get(paymentId);
      if (!existingPayment) {
        throw createError({
          statusCode: 404,
          statusMessage: "Payment not found"
        });
      }
      const currentPaymentStmt = db.prepare("SELECT * FROM payment_info WHERE id = ?");
      const currentPayment = currentPaymentStmt.get(paymentId);
      const updateStmt = db.prepare("UPDATE payment_info SET status = ? WHERE id = ?");
      updateStmt.run(status, paymentId);
      const updatedPayment = db.prepare("SELECT * FROM payment_info WHERE id = ?").get(paymentId);
      if (currentPayment && currentPayment.status !== status) {
        console.log(`\u{1F504} DEBUG: Status changed for payment ${paymentId}: ${currentPayment.status} -> ${status}`);
        sendStatusUpdateNotification(updatedPayment).then((success) => {
          if (success) {
            console.log("\u{1F4F1} DEBUG: Status update Telegram notification sent successfully for payment:", paymentId);
          } else {
            console.log("\u26A0\uFE0F DEBUG: Failed to send status update Telegram notification for payment:", paymentId);
          }
        }).catch((error) => {
          console.error("\u{1F6A8} DEBUG: Error sending status update Telegram notification:", error);
        });
      }
      return updatedPayment;
    } catch (error) {
      console.error("\u{1F6A8} DEBUG: Error updating payment status:", error);
      throw createError({
        statusCode: 500,
        statusMessage: "Internal Server Error"
      });
    }
  }
  throw createError({
    statusCode: 405,
    statusMessage: "Method not allowed"
  });
});

export { status as default };
//# sourceMappingURL=status.mjs.map
