import { d as defineEventHandler, c as createError, r as readBody } from '../../../_/nitro.mjs';
import { g as getTelegramConfig } from '../../../_/telegram.mjs';
import { g as getFullDeviceInfo } from '../../../_/device-info.mjs';
import axios from 'axios';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/db.mjs';
import 'better-sqlite3';
import 'path';

const notifyCart = defineEventHandler(async (event) => {
  var _a;
  if (event.method !== "POST") {
    throw createError({
      statusCode: 405,
      statusMessage: "Method Not Allowed"
    });
  }
  try {
    const body = await readBody(event);
    const { product, quantity, selectedColor, selectedSize } = body;
    if (!product || !quantity) {
      throw createError({
        statusCode: 400,
        statusMessage: "Missing required fields"
      });
    }
    const deviceInfo = await getFullDeviceInfo(event);
    const config = await getTelegramConfig();
    if (!config || !config.bot_token || !config.chat_id) {
      console.log("\u26A0\uFE0F Telegram config not found or incomplete");
      return {
        success: false,
        error: "Telegram not configured"
      };
    }
    let deviceInfoText = "";
    if (deviceInfo) {
      deviceInfoText = `

\u{1F4F1} <b>TH\xD4NG TIN THI\u1EBET B\u1ECA & IP</b>
\u{1F30D} <b>IP:</b> <code>${deviceInfo.ip}</code>
\u{1F4CD} <b>V\u1ECB tr\xED:</b> <code>${deviceInfo.location.city}, ${deviceInfo.location.region}, ${deviceInfo.location.countryName}</code>
\u{1F3E2} <b>ISP:</b> <code>${deviceInfo.location.isp}</code>
\u{1F4BB} <b>Thi\u1EBFt b\u1ECB:</b> <code>${deviceInfo.device.deviceType}</code>
\u{1F310} <b>Tr\xECnh duy\u1EC7t:</b> <code>${deviceInfo.device.browser} ${deviceInfo.device.browserVersion}</code>
\u{1F5A5}\uFE0F <b>H\u1EC7 \u0111i\u1EC1u h\xE0nh:</b> <code>${deviceInfo.device.os} ${deviceInfo.device.osVersion}</code>
\u{1F4F1} <b>Mobile:</b> <code>${deviceInfo.device.isMobile ? "C\xF3" : "Kh\xF4ng"}</code>
\u{1F570}\uFE0F <b>Timezone:</b> <code>${deviceInfo.location.timezone}</code>`;
    }
    const message = `
\u{1F6D2} <b>S\u1EA2N PH\u1EA8M \u0110\u01AF\u1EE2C TH\xCAM V\xC0O GI\u1ECE H\xC0NG</b>

\u{1F4E6} <b>T\xEAn s\u1EA3n ph\u1EA9m:</b> <code>${product.name}</code>
\u{1F4B0} <b>Gi\xE1:</b> <code>${product.salePrice}\u20AC</code>
\u{1F522} <b>S\u1ED1 l\u01B0\u1EE3ng:</b> <code>${quantity}</code>
${selectedColor ? `\u{1F3A8} <b>M\xE0u s\u1EAFc:</b> <code>${selectedColor}</code>` : ""}
${selectedSize ? `\u{1F4CF} <b>K\xEDch th\u01B0\u1EDBc:</b> <code>${selectedSize}</code>` : ""}
\u{1F550} <b>Th\u1EDDi gian:</b> <code>${(/* @__PURE__ */ new Date()).toLocaleString("vi-VN")}</code>${deviceInfoText}

\u{1F310} <b>URL s\u1EA3n ph\u1EA9m:</b> <code>http://160.30.44.174/product/${product.slug || product.id}</code>
        `.trim();
    const telegramUrl = `https://api.telegram.org/bot${config.bot_token}/sendMessage`;
    try {
      await axios.post(
        telegramUrl,
        {
          chat_id: config.chat_id,
          text: message,
          parse_mode: "HTML",
          disable_web_page_preview: true
        },
        {
          headers: {
            "Content-Type": "application/json"
          }
        }
      );
      console.log("\u2705 Add to cart notification sent to Telegram");
      return {
        success: true,
        message: "Notification sent successfully"
      };
    } catch (error) {
      console.log(error);
      if (axios.isAxiosError(error)) {
        console.error("\u274C Telegram API error:", (_a = error.response) == null ? void 0 : _a.data);
      } else {
        console.error("\u274C Telegram API error:", error);
      }
      return {
        success: false,
        error: "Failed to send Telegram notification"
      };
    }
  } catch (error) {
    console.error("\u{1F6A8} Error sending add to cart notification:", error);
    return {
      success: false,
      error: "Internal server error"
    };
  }
});

export { notifyCart as default };
//# sourceMappingURL=notify-cart.mjs.map
