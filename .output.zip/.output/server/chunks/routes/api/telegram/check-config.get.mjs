import { d as defineEventHandler } from '../../../_/nitro.mjs';
import { g as getTelegramConfig } from '../../../_/telegram.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/db.mjs';
import 'better-sqlite3';
import 'path';

const checkConfig_get = defineEventHandler(async (event) => {
  try {
    const config = await getTelegramConfig();
    if (config && config.bot_token && config.chat_id) {
      return {
        configured: true,
        message: "Telegram is configured"
      };
    } else {
      return {
        configured: false,
        message: "Telegram bot token or chat ID not configured in database"
      };
    }
  } catch (error) {
    console.error("Error checking Telegram config:", error);
    return {
      configured: false,
      message: "Error checking Telegram configuration",
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
});

export { checkConfig_get as default };
//# sourceMappingURL=check-config.get.mjs.map
