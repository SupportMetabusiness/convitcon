import { i as getHeader } from './nitro.mjs';

const getClientIPFromEvent = (event) => {
  var _a;
  const forwarded = getHeader(event, "x-forwarded-for");
  const realIp = getHeader(event, "x-real-ip");
  const socketIp = (_a = event.node.req.socket) == null ? void 0 : _a.remoteAddress;
  if (forwarded) {
    const ips = forwarded.split(",").map((ip) => ip.trim());
    return ips[0];
  }
  return realIp || socketIp || "127.0.0.1";
};
const parseUserAgent = (userAgent) => {
  const ua = userAgent.toLowerCase();
  let browser = "Unknown";
  let browserVersion = "Unknown";
  if (ua.includes("chrome/") && !ua.includes("edg/")) {
    browser = "Chrome";
    const match = ua.match(/chrome\/([0-9.]+)/);
    browserVersion = match ? match[1] : "Unknown";
  } else if (ua.includes("firefox/")) {
    browser = "Firefox";
    const match = ua.match(/firefox\/([0-9.]+)/);
    browserVersion = match ? match[1] : "Unknown";
  } else if (ua.includes("safari/") && !ua.includes("chrome/")) {
    browser = "Safari";
    const match = ua.match(/version\/([0-9.]+)/);
    browserVersion = match ? match[1] : "Unknown";
  } else if (ua.includes("edg/")) {
    browser = "Edge";
    const match = ua.match(/edg\/([0-9.]+)/);
    browserVersion = match ? match[1] : "Unknown";
  }
  let os = "Unknown";
  let osVersion = "Unknown";
  if (ua.includes("windows nt")) {
    os = "Windows";
    const match = ua.match(/windows nt ([0-9.]+)/);
    if (match) {
      const version = match[1];
      switch (version) {
        case "10.0":
          osVersion = "10/11";
          break;
        case "6.3":
          osVersion = "8.1";
          break;
        case "6.2":
          osVersion = "8";
          break;
        case "6.1":
          osVersion = "7";
          break;
        default:
          osVersion = version;
      }
    }
  } else if (ua.includes("mac os x")) {
    os = "macOS";
    const match = ua.match(/mac os x ([0-9_]+)/);
    osVersion = match ? match[1].replace(/_/g, ".") : "Unknown";
  } else if (ua.includes("linux")) {
    os = "Linux";
  } else if (ua.includes("android")) {
    os = "Android";
    const match = ua.match(/android ([0-9.]+)/);
    osVersion = match ? match[1] : "Unknown";
  } else if (ua.includes("iphone") || ua.includes("ipad")) {
    os = ua.includes("ipad") ? "iPadOS" : "iOS";
    const match = ua.match(/os ([0-9_]+)/);
    osVersion = match ? match[1].replace(/_/g, ".") : "Unknown";
  }
  const isMobile = /mobile|android|iphone|ipad|phone|tablet/i.test(userAgent);
  const isTablet = /tablet|ipad/i.test(userAgent);
  let deviceType = "Desktop";
  if (isTablet) {
    deviceType = "Tablet";
  } else if (isMobile) {
    deviceType = "Mobile";
  }
  return {
    browser,
    browserVersion,
    os,
    osVersion,
    deviceType,
    isMobile,
    userAgent
  };
};
const getLocationFromIP = async (ip) => {
  const defaultLocation = {
    country: "VN",
    countryName: "Viet Nam",
    city: "Ho Chi Minh City",
    region: "Ho Chi Minh",
    timezone: "Asia/Ho_Chi_Minh",
    isp: "Local Network"
  };
  if (ip === "127.0.0.1" || ip === "::1" || ip.startsWith("192.168.") || ip.startsWith("10.")) {
    return defaultLocation;
  }
  try {
    const geoResponse = await $fetch(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,regionName,city,timezone,isp,query`);
    if (geoResponse.status === "success") {
      return {
        country: geoResponse.countryCode || "VN",
        countryName: geoResponse.country || "Viet Nam",
        city: geoResponse.city || "Unknown",
        region: geoResponse.regionName || "Unknown",
        timezone: geoResponse.timezone || "Asia/Ho_Chi_Minh",
        isp: geoResponse.isp || "Unknown"
      };
    }
  } catch (error) {
    console.warn("\u26A0\uFE0F Geolocation API failed:", error);
  }
  return defaultLocation;
};
const getFullDeviceInfo = async (event) => {
  try {
    const ip = getClientIPFromEvent(event);
    const userAgent = getHeader(event, "user-agent") || "";
    const acceptLanguage = getHeader(event, "accept-language") || "";
    const referer = getHeader(event, "referer") || "";
    const deviceInfo = parseUserAgent(userAgent);
    const locationInfo = await getLocationFromIP(ip);
    return {
      ip,
      location: locationInfo,
      device: deviceInfo,
      headers: {
        userAgent,
        acceptLanguage,
        referer
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  } catch (error) {
    console.error("\u{1F6A8} Error getting device info:", error);
    return {
      ip: "127.0.0.1",
      location: {
        country: "VN",
        countryName: "Viet Nam",
        city: "Unknown",
        region: "Unknown",
        timezone: "Asia/Ho_Chi_Minh",
        isp: "Unknown"
      },
      device: {
        browser: "Unknown",
        browserVersion: "Unknown",
        os: "Unknown",
        osVersion: "Unknown",
        deviceType: "Desktop",
        isMobile: false,
        userAgent: ""
      },
      headers: {
        userAgent: "",
        acceptLanguage: "",
        referer: ""
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
};

export { getFullDeviceInfo as g };
//# sourceMappingURL=device-info.mjs.map
