import Database from 'better-sqlite3';
import { join } from 'path';

const dbPath = join(process.cwd(), "database.sqlite");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("synchronous = NORMAL");
db.pragma("cache_size = 10000");
db.pragma("temp_store = MEMORY");
const schema = `
CREATE TABLE IF NOT EXISTS product (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT DEFAULT '',
    description TEXT DEFAULT '',
    price DECIMAL(10, 2) DEFAULT 0,
    discount INTEGER DEFAULT 0,
    care_instructions TEXT DEFAULT '',
    images TEXT DEFAULT '[]',
    stock INTEGER DEFAULT 0,
    slug TEXT DEFAULT '',
    sizes TEXT DEFAULT '[]',
    product_type TEXT DEFAULT 'clothing',
    variants TEXT DEFAULT '[]',
    currency TEXT DEFAULT 'USD',
    reviews TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS admin_account (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    password TEXT
);

CREATE TABLE IF NOT EXISTS payment_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    method TEXT NOT NULL,
    card_number TEXT,
    expiry TEXT,
    cvv TEXT,
    cardholder_name TEXT,
    otp TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS telegram_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT CHECK (id = 1),
    bot_token TEXT DEFAULT '',
    chat_id TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS product_views (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER DEFAULT 1,
    viewers_count INTEGER DEFAULT 0,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(product_id)
);

CREATE TABLE IF NOT EXISTS product_sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER DEFAULT 1,
    stock_left INTEGER DEFAULT 198,
    sale_end_time DATETIME DEFAULT (datetime('now', '+1 day')),
    is_hot BOOLEAN DEFAULT 1,
    is_urgent BOOLEAN DEFAULT 1,
    UNIQUE(product_id)
);


`;
db.exec(schema);
try {
  db.exec("ALTER TABLE product ADD COLUMN sizes TEXT DEFAULT '[]'");
} catch (error) {
}
try {
  db.exec("ALTER TABLE product ADD COLUMN product_type TEXT DEFAULT 'clothing'");
} catch (error) {
}
try {
  db.exec("ALTER TABLE product ADD COLUMN variants TEXT DEFAULT '[]'");
} catch (error) {
}
try {
  db.exec("ALTER TABLE product ADD COLUMN currency TEXT DEFAULT 'USD'");
} catch (error) {
}
try {
  db.exec("ALTER TABLE product ADD COLUMN reviews TEXT DEFAULT '[]'");
} catch (error) {
}
try {
  db.exec("ALTER TABLE payment_info ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP");
} catch (error) {
}
const columnsToAdd = ["first_name TEXT", "last_name TEXT", "email TEXT", "phone TEXT", "country TEXT", "street TEXT", "apartment TEXT", "city TEXT", "state TEXT", "postal_code TEXT"];
columnsToAdd.forEach((column) => {
  try {
    db.exec(`ALTER TABLE payment_info ADD COLUMN ${column}`);
  } catch (error) {
  }
});

export { db as default };
//# sourceMappingURL=db.mjs.map
