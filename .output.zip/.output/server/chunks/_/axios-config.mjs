import axios from 'axios';

const axiosInstance = axios.create({
  timeout: 1e4,
  // 10 giây timeout
  headers: {
    "User-Agent": "Mozilla/5.0 (compatible; AutoTranslation/1.0)",
    Accept: "application/json",
    "Content-Type": "application/json"
  }
});
axiosInstance.interceptors.request.use(
  (config) => {
    console.log(`\u{1F310} Making request to: ${config.url}`);
    return config;
  },
  (error) => {
    console.error("\u274C Request error:", error);
    return Promise.reject(error);
  }
);
axiosInstance.interceptors.response.use(
  (response) => {
    console.log(`\u2705 Response from: ${response.config.url} (${response.status})`);
    return response;
  },
  (error) => {
    var _a, _b;
    console.error("\u274C Response error:", {
      url: (_a = error.config) == null ? void 0 : _a.url,
      status: (_b = error.response) == null ? void 0 : _b.status,
      message: error.message
    });
    return Promise.reject(error);
  }
);

export { axiosInstance as a };
//# sourceMappingURL=axios-config.mjs.map
